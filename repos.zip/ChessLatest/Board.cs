﻿namespace ChessLatest
{
    internal class Board
    {
        internal static void PlaceFigures()
        {
            ChessPiece piece = new ChessPiece(PieceType.Rook, Color.Gray);
            Label pieceLabel = new Label
            {
                Text = piece.Symbol,
                Font = new Font("Arial", 24, FontStyle.Regular),
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                ForeColor = Color.White,
                BackColor = Color.Transparent // Make the background transparent
            };
            Form1.tableLayoutPanel1.Controls.Add(pieceLabel, 0, 0); // Position the rook at row 0, column 0.
        }
    }
}
