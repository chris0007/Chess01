﻿using System.Windows.Forms;
using static ChessLibrary.ChessPieceModel;

namespace ChessControls
{
    public partial class ChessSquare : Label
    {
        public ChessPieceEnum ChessPieceEnum { get; set; }
        public ChessSquare()
        {
            Margin = new Padding(0);
            Dock = DockStyle.Fill;
            TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            InitializeComponent();
        }
    }
}
