﻿using ChessControls;

namespace ChessLogic
{
    public class Class1
    {
        public void DetermineValidMoves(ChessSquare chessSquare)
        {

        }
    }
}
