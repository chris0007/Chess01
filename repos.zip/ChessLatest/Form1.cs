namespace ChessLatest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Create and position the chess pieces

            tableLayoutPanel1.CellPaint += tableLayoutPanel1_CellPaint;
        }


        private void tableLayoutPanel1_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {
            int row = e.Row;
            int col = e.Column;

            Color backgroundColor = (row + col) % 2 == 0 ? Color.Black : Color.White;

            using (var brush = new SolidBrush(backgroundColor))
            {
                e.Graphics.FillRectangle(brush, e.CellBounds);
            }
        }

    }
}