﻿namespace ChessLibrary
{
    public class ChessPieceModel
    {
        public ChessPieceEnum ChessPiece { get; set; }

        public enum ChessPieceEnum
        {
            None,
            WhiteKing,
            WhiteQueen,
            WhiteRook,
            WhiteBishop,
            WhiteKnight,
            WhitePawn,
            BlackKing,
            BlackQueen,
            BlackRook,
            BlackBishop,
            BlackKnight,
            BlackPawn
        }
    }
}
