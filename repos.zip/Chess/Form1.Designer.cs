﻿namespace Chess
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chessBoardTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.A8 = new ChessControls.ChessSquare();
            this.B8 = new ChessControls.ChessSquare();
            this.C8 = new ChessControls.ChessSquare();
            this.D8 = new ChessControls.ChessSquare();
            this.E8 = new ChessControls.ChessSquare();
            this.F8 = new ChessControls.ChessSquare();
            this.G8 = new ChessControls.ChessSquare();
            this.H8 = new ChessControls.ChessSquare();
            this.A7 = new ChessControls.ChessSquare();
            this.B7 = new ChessControls.ChessSquare();
            this.C7 = new ChessControls.ChessSquare();
            this.D7 = new ChessControls.ChessSquare();
            this.E7 = new ChessControls.ChessSquare();
            this.F7 = new ChessControls.ChessSquare();
            this.G7 = new ChessControls.ChessSquare();
            this.H7 = new ChessControls.ChessSquare();
            this.A6 = new ChessControls.ChessSquare();
            this.B6 = new ChessControls.ChessSquare();
            this.C6 = new ChessControls.ChessSquare();
            this.D6 = new ChessControls.ChessSquare();
            this.E6 = new ChessControls.ChessSquare();
            this.F6 = new ChessControls.ChessSquare();
            this.G6 = new ChessControls.ChessSquare();
            this.H6 = new ChessControls.ChessSquare();
            this.A5 = new ChessControls.ChessSquare();
            this.B5 = new ChessControls.ChessSquare();
            this.C5 = new ChessControls.ChessSquare();
            this.D5 = new ChessControls.ChessSquare();
            this.E5 = new ChessControls.ChessSquare();
            this.F5 = new ChessControls.ChessSquare();
            this.G5 = new ChessControls.ChessSquare();
            this.H5 = new ChessControls.ChessSquare();
            this.A4 = new ChessControls.ChessSquare();
            this.B4 = new ChessControls.ChessSquare();
            this.C4 = new ChessControls.ChessSquare();
            this.D4 = new ChessControls.ChessSquare();
            this.E4 = new ChessControls.ChessSquare();
            this.F4 = new ChessControls.ChessSquare();
            this.G4 = new ChessControls.ChessSquare();
            this.H4 = new ChessControls.ChessSquare();
            this.A3 = new ChessControls.ChessSquare();
            this.B3 = new ChessControls.ChessSquare();
            this.C3 = new ChessControls.ChessSquare();
            this.D3 = new ChessControls.ChessSquare();
            this.E3 = new ChessControls.ChessSquare();
            this.F3 = new ChessControls.ChessSquare();
            this.G3 = new ChessControls.ChessSquare();
            this.H3 = new ChessControls.ChessSquare();
            this.A2 = new ChessControls.ChessSquare();
            this.B2 = new ChessControls.ChessSquare();
            this.C2 = new ChessControls.ChessSquare();
            this.D2 = new ChessControls.ChessSquare();
            this.E2 = new ChessControls.ChessSquare();
            this.F2 = new ChessControls.ChessSquare();
            this.G2 = new ChessControls.ChessSquare();
            this.H2 = new ChessControls.ChessSquare();
            this.A1 = new ChessControls.ChessSquare();
            this.B1 = new ChessControls.ChessSquare();
            this.C1 = new ChessControls.ChessSquare();
            this.D1 = new ChessControls.ChessSquare();
            this.E1 = new ChessControls.ChessSquare();
            this.F1 = new ChessControls.ChessSquare();
            this.G1 = new ChessControls.ChessSquare();
            this.H1 = new ChessControls.ChessSquare();
            this.chessBoardTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // chessBoardTableLayoutPanel
            // 
            this.chessBoardTableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.chessBoardTableLayoutPanel.ColumnCount = 8;
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.Controls.Add(this.H1, 7, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G1, 6, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F1, 5, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E1, 4, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D1, 3, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C1, 2, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B1, 1, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A1, 0, 7);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H2, 7, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G2, 6, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F2, 5, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E2, 4, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D2, 3, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C2, 2, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B2, 1, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A2, 0, 6);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H3, 7, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G3, 6, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F3, 5, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E3, 4, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D3, 3, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C3, 2, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B3, 1, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A3, 0, 5);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H4, 7, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G4, 6, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F4, 5, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E4, 4, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D4, 3, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C4, 2, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B4, 1, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A4, 0, 4);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H5, 7, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G5, 6, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F5, 5, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E5, 4, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D5, 3, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C5, 2, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B5, 1, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A5, 0, 3);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H6, 7, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G6, 6, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F6, 5, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E6, 4, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D6, 3, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C6, 2, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B6, 1, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A6, 0, 2);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H7, 7, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G7, 6, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F7, 5, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E7, 4, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D7, 3, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C7, 2, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B7, 1, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A7, 0, 1);
            this.chessBoardTableLayoutPanel.Controls.Add(this.H8, 7, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.G8, 6, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.F8, 5, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.E8, 4, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.D8, 3, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.C8, 2, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.A8, 0, 0);
            this.chessBoardTableLayoutPanel.Controls.Add(this.B8, 1, 0);
            this.chessBoardTableLayoutPanel.Location = new System.Drawing.Point(14, 12);
            this.chessBoardTableLayoutPanel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chessBoardTableLayoutPanel.Name = "chessBoardTableLayoutPanel";
            this.chessBoardTableLayoutPanel.RowCount = 8;
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.chessBoardTableLayoutPanel.Size = new System.Drawing.Size(1082, 574);
            this.chessBoardTableLayoutPanel.TabIndex = 0;
            // 
            // A8
            // 
            this.A8.AutoSize = true;
            this.A8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackRook;
            this.A8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A8.Location = new System.Drawing.Point(3, 3);
            this.A8.Margin = new System.Windows.Forms.Padding(0);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(131, 68);
            this.A8.TabIndex = 0;
            this.A8.Text = "♜";
            this.A8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B8
            // 
            this.B8.AutoSize = true;
            this.B8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.B8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackKnight;
            this.B8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.Location = new System.Drawing.Point(137, 3);
            this.B8.Margin = new System.Windows.Forms.Padding(0);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(131, 68);
            this.B8.TabIndex = 1;
            this.B8.Text = "♞";
            this.B8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C8
            // 
            this.C8.AutoSize = true;
            this.C8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackBishop;
            this.C8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.Location = new System.Drawing.Point(271, 3);
            this.C8.Margin = new System.Windows.Forms.Padding(0);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(131, 68);
            this.C8.TabIndex = 2;
            this.C8.Text = "♝";
            this.C8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D8
            // 
            this.D8.AutoSize = true;
            this.D8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.D8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackQueen;
            this.D8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D8.Location = new System.Drawing.Point(405, 3);
            this.D8.Margin = new System.Windows.Forms.Padding(0);
            this.D8.Name = "D8";
            this.D8.Size = new System.Drawing.Size(131, 68);
            this.D8.TabIndex = 3;
            this.D8.Text = "♛";
            this.D8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E8
            // 
            this.E8.AutoSize = true;
            this.E8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackKing;
            this.E8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E8.Location = new System.Drawing.Point(539, 3);
            this.E8.Margin = new System.Windows.Forms.Padding(0);
            this.E8.Name = "E8";
            this.E8.Size = new System.Drawing.Size(131, 68);
            this.E8.TabIndex = 4;
            this.E8.Text = "♚";
            this.E8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F8
            // 
            this.F8.AutoSize = true;
            this.F8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.F8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackBishop;
            this.F8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F8.Location = new System.Drawing.Point(673, 3);
            this.F8.Margin = new System.Windows.Forms.Padding(0);
            this.F8.Name = "F8";
            this.F8.Size = new System.Drawing.Size(131, 68);
            this.F8.TabIndex = 5;
            this.F8.Text = "♝";
            this.F8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G8
            // 
            this.G8.AutoSize = true;
            this.G8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackKnight;
            this.G8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G8.Location = new System.Drawing.Point(807, 3);
            this.G8.Margin = new System.Windows.Forms.Padding(0);
            this.G8.Name = "G8";
            this.G8.Size = new System.Drawing.Size(131, 68);
            this.G8.TabIndex = 6;
            this.G8.Text = "♞";
            this.G8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H8
            // 
            this.H8.AutoSize = true;
            this.H8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.H8.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackRook;
            this.H8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H8.Location = new System.Drawing.Point(941, 3);
            this.H8.Margin = new System.Windows.Forms.Padding(0);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(138, 68);
            this.H8.TabIndex = 7;
            this.H8.Text = "♜";
            this.H8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A7
            // 
            this.A7.AutoSize = true;
            this.A7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.A7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.A7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A7.Location = new System.Drawing.Point(3, 74);
            this.A7.Margin = new System.Windows.Forms.Padding(0);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(131, 68);
            this.A7.TabIndex = 8;
            this.A7.Text = "♟";
            this.A7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B7
            // 
            this.B7.AutoSize = true;
            this.B7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.B7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(137, 74);
            this.B7.Margin = new System.Windows.Forms.Padding(0);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(131, 68);
            this.B7.TabIndex = 9;
            this.B7.Text = "♟";
            this.B7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C7
            // 
            this.C7.AutoSize = true;
            this.C7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.C7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.C7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.Location = new System.Drawing.Point(271, 74);
            this.C7.Margin = new System.Windows.Forms.Padding(0);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(131, 68);
            this.C7.TabIndex = 10;
            this.C7.Text = "♟";
            this.C7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D7
            // 
            this.D7.AutoSize = true;
            this.D7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.D7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D7.Location = new System.Drawing.Point(405, 74);
            this.D7.Margin = new System.Windows.Forms.Padding(0);
            this.D7.Name = "D7";
            this.D7.Size = new System.Drawing.Size(131, 68);
            this.D7.TabIndex = 11;
            this.D7.Text = "♟";
            this.D7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E7
            // 
            this.E7.AutoSize = true;
            this.E7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.E7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.E7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E7.Location = new System.Drawing.Point(539, 74);
            this.E7.Margin = new System.Windows.Forms.Padding(0);
            this.E7.Name = "E7";
            this.E7.Size = new System.Drawing.Size(131, 68);
            this.E7.TabIndex = 12;
            this.E7.Text = "♟";
            this.E7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F7
            // 
            this.F7.AutoSize = true;
            this.F7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.F7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F7.Location = new System.Drawing.Point(673, 74);
            this.F7.Margin = new System.Windows.Forms.Padding(0);
            this.F7.Name = "F7";
            this.F7.Size = new System.Drawing.Size(131, 68);
            this.F7.TabIndex = 13;
            this.F7.Text = "♟";
            this.F7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G7
            // 
            this.G7.AutoSize = true;
            this.G7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.G7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.G7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G7.Location = new System.Drawing.Point(807, 74);
            this.G7.Margin = new System.Windows.Forms.Padding(0);
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(131, 68);
            this.G7.TabIndex = 14;
            this.G7.Text = "♟";
            this.G7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H7
            // 
            this.H7.AutoSize = true;
            this.H7.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.BlackPawn;
            this.H7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H7.Location = new System.Drawing.Point(941, 74);
            this.H7.Margin = new System.Windows.Forms.Padding(0);
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(138, 68);
            this.H7.TabIndex = 15;
            this.H7.Text = "♟";
            this.H7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A6
            // 
            this.A6.AutoSize = true;
            this.A6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.A6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.Location = new System.Drawing.Point(3, 145);
            this.A6.Margin = new System.Windows.Forms.Padding(0);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(131, 68);
            this.A6.TabIndex = 16;
            this.A6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B6
            // 
            this.B6.AutoSize = true;
            this.B6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.B6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.B6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(137, 145);
            this.B6.Margin = new System.Windows.Forms.Padding(0);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(131, 68);
            this.B6.TabIndex = 17;
            this.B6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C6
            // 
            this.C6.AutoSize = true;
            this.C6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.C6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.Location = new System.Drawing.Point(271, 145);
            this.C6.Margin = new System.Windows.Forms.Padding(0);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(131, 68);
            this.C6.TabIndex = 18;
            this.C6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D6
            // 
            this.D6.AutoSize = true;
            this.D6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.D6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.D6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D6.Location = new System.Drawing.Point(405, 145);
            this.D6.Margin = new System.Windows.Forms.Padding(0);
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(131, 68);
            this.D6.TabIndex = 19;
            this.D6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E6
            // 
            this.E6.AutoSize = true;
            this.E6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.E6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E6.Location = new System.Drawing.Point(539, 145);
            this.E6.Margin = new System.Windows.Forms.Padding(0);
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(131, 68);
            this.E6.TabIndex = 20;
            this.E6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F6
            // 
            this.F6.AutoSize = true;
            this.F6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.F6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.F6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F6.Location = new System.Drawing.Point(673, 145);
            this.F6.Margin = new System.Windows.Forms.Padding(0);
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(131, 68);
            this.F6.TabIndex = 21;
            this.F6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G6
            // 
            this.G6.AutoSize = true;
            this.G6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.G6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G6.Location = new System.Drawing.Point(807, 145);
            this.G6.Margin = new System.Windows.Forms.Padding(0);
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(131, 68);
            this.G6.TabIndex = 22;
            this.G6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H6
            // 
            this.H6.AutoSize = true;
            this.H6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.H6.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.H6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H6.Location = new System.Drawing.Point(941, 145);
            this.H6.Margin = new System.Windows.Forms.Padding(0);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(138, 68);
            this.H6.TabIndex = 23;
            this.H6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A5
            // 
            this.A5.AutoSize = true;
            this.A5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.A5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.A5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(3, 216);
            this.A5.Margin = new System.Windows.Forms.Padding(0);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(131, 68);
            this.A5.TabIndex = 24;
            this.A5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B5
            // 
            this.B5.AutoSize = true;
            this.B5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.B5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(137, 216);
            this.B5.Margin = new System.Windows.Forms.Padding(0);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(131, 68);
            this.B5.TabIndex = 25;
            this.B5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C5
            // 
            this.C5.AutoSize = true;
            this.C5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.C5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.C5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(271, 216);
            this.C5.Margin = new System.Windows.Forms.Padding(0);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(131, 68);
            this.C5.TabIndex = 26;
            this.C5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D5
            // 
            this.D5.AutoSize = true;
            this.D5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.D5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D5.Location = new System.Drawing.Point(405, 216);
            this.D5.Margin = new System.Windows.Forms.Padding(0);
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(131, 68);
            this.D5.TabIndex = 27;
            this.D5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E5
            // 
            this.E5.AutoSize = true;
            this.E5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.E5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.E5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E5.Location = new System.Drawing.Point(539, 216);
            this.E5.Margin = new System.Windows.Forms.Padding(0);
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(131, 68);
            this.E5.TabIndex = 28;
            this.E5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F5
            // 
            this.F5.AutoSize = true;
            this.F5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.F5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F5.Location = new System.Drawing.Point(673, 216);
            this.F5.Margin = new System.Windows.Forms.Padding(0);
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(131, 68);
            this.F5.TabIndex = 29;
            this.F5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G5
            // 
            this.G5.AutoSize = true;
            this.G5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.G5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.G5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G5.Location = new System.Drawing.Point(807, 216);
            this.G5.Margin = new System.Windows.Forms.Padding(0);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(131, 68);
            this.G5.TabIndex = 30;
            this.G5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H5
            // 
            this.H5.AutoSize = true;
            this.H5.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.H5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H5.Location = new System.Drawing.Point(941, 216);
            this.H5.Margin = new System.Windows.Forms.Padding(0);
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(138, 68);
            this.H5.TabIndex = 31;
            this.H5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A4
            // 
            this.A4.AutoSize = true;
            this.A4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.A4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(3, 287);
            this.A4.Margin = new System.Windows.Forms.Padding(0);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(131, 68);
            this.A4.TabIndex = 32;
            this.A4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B4
            // 
            this.B4.AutoSize = true;
            this.B4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.B4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.B4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(137, 287);
            this.B4.Margin = new System.Windows.Forms.Padding(0);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(131, 68);
            this.B4.TabIndex = 33;
            this.B4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C4
            // 
            this.C4.AutoSize = true;
            this.C4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.C4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(271, 287);
            this.C4.Margin = new System.Windows.Forms.Padding(0);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(131, 68);
            this.C4.TabIndex = 34;
            this.C4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D4
            // 
            this.D4.AutoSize = true;
            this.D4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.D4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.D4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D4.Location = new System.Drawing.Point(405, 287);
            this.D4.Margin = new System.Windows.Forms.Padding(0);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(131, 68);
            this.D4.TabIndex = 35;
            this.D4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E4
            // 
            this.E4.AutoSize = true;
            this.E4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.E4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E4.Location = new System.Drawing.Point(539, 287);
            this.E4.Margin = new System.Windows.Forms.Padding(0);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(131, 68);
            this.E4.TabIndex = 36;
            this.E4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F4
            // 
            this.F4.AutoSize = true;
            this.F4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.F4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.F4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F4.Location = new System.Drawing.Point(673, 287);
            this.F4.Margin = new System.Windows.Forms.Padding(0);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(131, 68);
            this.F4.TabIndex = 37;
            this.F4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G4
            // 
            this.G4.AutoSize = true;
            this.G4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.G4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G4.Location = new System.Drawing.Point(807, 287);
            this.G4.Margin = new System.Windows.Forms.Padding(0);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(131, 68);
            this.G4.TabIndex = 38;
            this.G4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H4
            // 
            this.H4.AutoSize = true;
            this.H4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.H4.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.H4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H4.Location = new System.Drawing.Point(941, 287);
            this.H4.Margin = new System.Windows.Forms.Padding(0);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(138, 68);
            this.H4.TabIndex = 39;
            this.H4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A3
            // 
            this.A3.AutoSize = true;
            this.A3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.A3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.A3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(3, 358);
            this.A3.Margin = new System.Windows.Forms.Padding(0);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(131, 68);
            this.A3.TabIndex = 40;
            this.A3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B3
            // 
            this.B3.AutoSize = true;
            this.B3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.B3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(137, 358);
            this.B3.Margin = new System.Windows.Forms.Padding(0);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(131, 68);
            this.B3.TabIndex = 41;
            this.B3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C3
            // 
            this.C3.AutoSize = true;
            this.C3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.C3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.C3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(271, 358);
            this.C3.Margin = new System.Windows.Forms.Padding(0);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(131, 68);
            this.C3.TabIndex = 42;
            this.C3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D3
            // 
            this.D3.AutoSize = true;
            this.D3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.D3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D3.Location = new System.Drawing.Point(405, 358);
            this.D3.Margin = new System.Windows.Forms.Padding(0);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(131, 68);
            this.D3.TabIndex = 43;
            this.D3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E3
            // 
            this.E3.AutoSize = true;
            this.E3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.E3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.E3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E3.Location = new System.Drawing.Point(539, 358);
            this.E3.Margin = new System.Windows.Forms.Padding(0);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(131, 68);
            this.E3.TabIndex = 44;
            this.E3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F3
            // 
            this.F3.AutoSize = true;
            this.F3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.F3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F3.Location = new System.Drawing.Point(673, 358);
            this.F3.Margin = new System.Windows.Forms.Padding(0);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(131, 68);
            this.F3.TabIndex = 45;
            this.F3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G3
            // 
            this.G3.AutoSize = true;
            this.G3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.G3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.G3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G3.Location = new System.Drawing.Point(807, 358);
            this.G3.Margin = new System.Windows.Forms.Padding(0);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(131, 68);
            this.G3.TabIndex = 46;
            this.G3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H3
            // 
            this.H3.AutoSize = true;
            this.H3.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.None;
            this.H3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H3.Location = new System.Drawing.Point(941, 358);
            this.H3.Margin = new System.Windows.Forms.Padding(0);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(138, 68);
            this.H3.TabIndex = 47;
            this.H3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A2
            // 
            this.A2.AutoSize = true;
            this.A2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.A2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(3, 429);
            this.A2.Margin = new System.Windows.Forms.Padding(0);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(131, 68);
            this.A2.TabIndex = 48;
            this.A2.Text = "♙";
            this.A2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B2
            // 
            this.B2.AutoSize = true;
            this.B2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.B2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.B2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(137, 429);
            this.B2.Margin = new System.Windows.Forms.Padding(0);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(131, 68);
            this.B2.TabIndex = 49;
            this.B2.Text = "♙";
            this.B2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C2
            // 
            this.C2.AutoSize = true;
            this.C2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.C2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(271, 429);
            this.C2.Margin = new System.Windows.Forms.Padding(0);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(131, 68);
            this.C2.TabIndex = 50;
            this.C2.Text = "♙";
            this.C2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D2
            // 
            this.D2.AutoSize = true;
            this.D2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.D2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.D2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2.Location = new System.Drawing.Point(405, 429);
            this.D2.Margin = new System.Windows.Forms.Padding(0);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(131, 68);
            this.D2.TabIndex = 51;
            this.D2.Text = "♙";
            this.D2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E2
            // 
            this.E2.AutoSize = true;
            this.E2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.E2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E2.Location = new System.Drawing.Point(539, 429);
            this.E2.Margin = new System.Windows.Forms.Padding(0);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(131, 68);
            this.E2.TabIndex = 52;
            this.E2.Text = "♙";
            this.E2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F2
            // 
            this.F2.AutoSize = true;
            this.F2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.F2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.F2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F2.Location = new System.Drawing.Point(673, 429);
            this.F2.Margin = new System.Windows.Forms.Padding(0);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(131, 68);
            this.F2.TabIndex = 53;
            this.F2.Text = "♙";
            this.F2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G2
            // 
            this.G2.AutoSize = true;
            this.G2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.G2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G2.Location = new System.Drawing.Point(807, 429);
            this.G2.Margin = new System.Windows.Forms.Padding(0);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(131, 68);
            this.G2.TabIndex = 54;
            this.G2.Text = "♙";
            this.G2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H2
            // 
            this.H2.AutoSize = true;
            this.H2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.H2.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhitePawn;
            this.H2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H2.Location = new System.Drawing.Point(941, 429);
            this.H2.Margin = new System.Windows.Forms.Padding(0);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(138, 68);
            this.H2.TabIndex = 55;
            this.H2.Text = "♙";
            this.H2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.A1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteRook;
            this.A1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(3, 500);
            this.A1.Margin = new System.Windows.Forms.Padding(0);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(131, 71);
            this.A1.TabIndex = 56;
            this.A1.Text = "♖";
            this.A1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteKnight;
            this.B1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(137, 500);
            this.B1.Margin = new System.Windows.Forms.Padding(0);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(131, 71);
            this.B1.TabIndex = 57;
            this.B1.Text = "♘";
            this.B1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // C1
            // 
            this.C1.AutoSize = true;
            this.C1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.C1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteBishop;
            this.C1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(271, 500);
            this.C1.Margin = new System.Windows.Forms.Padding(0);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(131, 71);
            this.C1.TabIndex = 58;
            this.C1.Text = "♗";
            this.C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // D1
            // 
            this.D1.AutoSize = true;
            this.D1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteQueen;
            this.D1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.D1.Location = new System.Drawing.Point(405, 500);
            this.D1.Margin = new System.Windows.Forms.Padding(0);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(131, 71);
            this.D1.TabIndex = 59;
            this.D1.Text = "♕";
            this.D1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // E1
            // 
            this.E1.AutoSize = true;
            this.E1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.E1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteKing;
            this.E1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.E1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E1.Location = new System.Drawing.Point(539, 500);
            this.E1.Margin = new System.Windows.Forms.Padding(0);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(131, 71);
            this.E1.TabIndex = 60;
            this.E1.Text = "♔";
            this.E1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // F1
            // 
            this.F1.AutoSize = true;
            this.F1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteBishop;
            this.F1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.F1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F1.Location = new System.Drawing.Point(673, 500);
            this.F1.Margin = new System.Windows.Forms.Padding(0);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(131, 71);
            this.F1.TabIndex = 61;
            this.F1.Text = "♗";
            this.F1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // G1
            // 
            this.G1.AutoSize = true;
            this.G1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.G1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteKnight;
            this.G1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.G1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G1.Location = new System.Drawing.Point(807, 500);
            this.G1.Margin = new System.Windows.Forms.Padding(0);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(131, 71);
            this.G1.TabIndex = 62;
            this.G1.Text = "♘";
            this.G1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // H1
            // 
            this.H1.AutoSize = true;
            this.H1.BackColor = System.Drawing.SystemColors.Control;
            this.H1.ChessPieceEnum = ChessLibrary.ChessPieceModel.ChessPieceEnum.WhiteRook;
            this.H1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.H1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H1.Location = new System.Drawing.Point(941, 500);
            this.H1.Margin = new System.Windows.Forms.Padding(0);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(138, 71);
            this.H1.TabIndex = 63;
            this.H1.Text = "♖";
            this.H1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 599);
            this.Controls.Add(this.chessBoardTableLayoutPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.chessBoardTableLayoutPanel.ResumeLayout(false);
            this.chessBoardTableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel chessBoardTableLayoutPanel;
        private ChessControls.ChessSquare A8;
        private ChessControls.ChessSquare B8;
        private ChessControls.ChessSquare H1;
        private ChessControls.ChessSquare G1;
        private ChessControls.ChessSquare F1;
        private ChessControls.ChessSquare E1;
        private ChessControls.ChessSquare D1;
        private ChessControls.ChessSquare C1;
        private ChessControls.ChessSquare B1;
        private ChessControls.ChessSquare A1;
        private ChessControls.ChessSquare H2;
        private ChessControls.ChessSquare G2;
        private ChessControls.ChessSquare F2;
        private ChessControls.ChessSquare E2;
        private ChessControls.ChessSquare D2;
        private ChessControls.ChessSquare C2;
        private ChessControls.ChessSquare B2;
        private ChessControls.ChessSquare A2;
        private ChessControls.ChessSquare H3;
        private ChessControls.ChessSquare G3;
        private ChessControls.ChessSquare F3;
        private ChessControls.ChessSquare E3;
        private ChessControls.ChessSquare D3;
        private ChessControls.ChessSquare C3;
        private ChessControls.ChessSquare B3;
        private ChessControls.ChessSquare A3;
        private ChessControls.ChessSquare H4;
        private ChessControls.ChessSquare G4;
        private ChessControls.ChessSquare F4;
        private ChessControls.ChessSquare E4;
        private ChessControls.ChessSquare D4;
        private ChessControls.ChessSquare C4;
        private ChessControls.ChessSquare B4;
        private ChessControls.ChessSquare A4;
        private ChessControls.ChessSquare H5;
        private ChessControls.ChessSquare G5;
        private ChessControls.ChessSquare F5;
        private ChessControls.ChessSquare E5;
        private ChessControls.ChessSquare D5;
        private ChessControls.ChessSquare C5;
        private ChessControls.ChessSquare B5;
        private ChessControls.ChessSquare A5;
        private ChessControls.ChessSquare H6;
        private ChessControls.ChessSquare G6;
        private ChessControls.ChessSquare F6;
        private ChessControls.ChessSquare E6;
        private ChessControls.ChessSquare D6;
        private ChessControls.ChessSquare C6;
        private ChessControls.ChessSquare B6;
        private ChessControls.ChessSquare A6;
        private ChessControls.ChessSquare H7;
        private ChessControls.ChessSquare G7;
        private ChessControls.ChessSquare F7;
        private ChessControls.ChessSquare E7;
        private ChessControls.ChessSquare D7;
        private ChessControls.ChessSquare C7;
        private ChessControls.ChessSquare B7;
        private ChessControls.ChessSquare A7;
        private ChessControls.ChessSquare H8;
        private ChessControls.ChessSquare G8;
        private ChessControls.ChessSquare F8;
        private ChessControls.ChessSquare E8;
        private ChessControls.ChessSquare D8;
        private ChessControls.ChessSquare C8;
    }
}

