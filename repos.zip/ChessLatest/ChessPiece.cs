﻿namespace ChessLatest
{
    internal class ChessPiece
    {
        public PieceType Type { get; }
        public Color Color { get; }
        public string Symbol { get; }

        public ChessPiece(PieceType type, Color color)
        {
            Type = type;
            Color = color;
            Symbol = GetPieceSymbol(type, color);
        }

        private string GetPieceSymbol(PieceType type, Color color)
        {
            switch (type)
            {
                case PieceType.Pawn:
                    return color == Color.White ? "♙" : "♟";
                case PieceType.Rook:
                    return color == Color.White ? "♖" : "♜";
                case PieceType.Knight:
                    return color == Color.White ? "♘" : "♞";
                case PieceType.Bishop:
                    return color == Color.White ? "♗" : "♝";
                case PieceType.Queen:
                    return color == Color.White ? "♕" : "♛";
                case PieceType.King:
                    return color == Color.White ? "♔" : "♚";
                default:
                    return ""; // Return an empty string for unknown pieces.
            }
        }

    }
}
