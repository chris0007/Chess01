﻿using System.Windows.Forms;

namespace Chess
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void chessBoardTableLayoutPanel_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {

        }

        private void label15_Click(object sender, System.EventArgs e)
        {

        }

        private void chessBoardTableLayoutPanel_Click(object sender, System.EventArgs e)
        {

        }
    }
}
